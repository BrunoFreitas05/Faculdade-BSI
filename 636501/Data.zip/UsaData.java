public class UsaData {
    public static void main(String[] args) {
        Data data = new Data();
        
        data.setDia(11);
        data.setMes(11);
        data.setAno(2016);
        
        System.out.println(data.mostrarData());
    }
}
